package ArrayExercitii;

public class ArrayEx1 {
    public static void main(String[] args) {
        String[] cars = {"Volvo", "BMW", "Ford", "Duster"};
        for (String i : cars) {
            System.out.println(i);
        }
    }
}
